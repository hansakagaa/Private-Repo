package lk.ijse.pos.dao;

public interface SuperDAO {
}
