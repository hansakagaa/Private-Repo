package lk.ijse.pos.dao.custom.impl;

import lk.ijse.pos.dao.custom.QueryDAO;

public class QueryDAOImpl implements QueryDAO {
}
