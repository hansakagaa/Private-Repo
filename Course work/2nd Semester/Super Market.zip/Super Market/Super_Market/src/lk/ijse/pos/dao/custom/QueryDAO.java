package lk.ijse.pos.dao.custom;

import lk.ijse.pos.dao.SuperDAO;

public interface QueryDAO extends SuperDAO {
}
