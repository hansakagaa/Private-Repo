package controller;

import db.DbConnection;
import model.Customer;
import model.Order;
import model.OrderDetails;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class OrderController {
    public String getOrderId() throws SQLException, ClassNotFoundException {
        return getId();
    }

    static String getId() throws SQLException, ClassNotFoundException {
        ResultSet rst = DbConnection.getInstance()
                .getConnection().prepareStatement(
                        "SELECT orderId FROM `Order` ORDER BY orderId DESC LIMIT 1"
                ).executeQuery();
        if (rst.next()){

            int tempId = Integer.
                    parseInt(rst.getString(1).split("-")[1]);
            tempId=tempId+1;
            if (tempId<9){
                return "O00-00"+tempId;
            }else if(tempId<99){
                return "O00-0"+tempId;
            }else{
                return "O00-"+tempId;
            }

        }else{
            return "O00-001";
        }
    }

    public boolean saveOrderDetails(OrderDetails orderDetails) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement(
                "INSERT INTO `Order Details` VALUES(?,?,?,?,?,?)");
        stm.setObject(1,orderDetails.getOrderId());
        stm.setObject(2,orderDetails.getCusId());
        stm.setObject(3,orderDetails.getOrderQty());
        stm.setObject(4,orderDetails.getOrderTime());
        stm.setObject(5,orderDetails.getOrderDate());
        stm.setObject(6,orderDetails.getTotalAmount());

        return stm.executeUpdate()>0;
    }

    public boolean saveOrder(Order order) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement(
                "INSERT INTO `Order` VALUES(?,?,?,?,?,?)");
        stm.setObject(1,order.getOrderId());
        stm.setObject(2,order.getMPIds());
        stm.setObject(3,order.getMealQty());
        stm.setObject(4,order.getPaidAmount());
        stm.setObject(5,order.getDiscountPrice());
        stm.setObject(6,order.getTotalAmount());

        return stm.executeUpdate()>0;
    }
    public int getOrderCount() throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement(
                "SELECT COUNT(*) FROM `Order`");
        ResultSet rst = stm.executeQuery();
        int  orderCount =0;
        if (rst.next()) {
            orderCount = rst.getInt(1);
        }
        return orderCount;
    }
}
